---
title: 快速幂
date: 2018-12-01 20:01:22
categories: 普及
tags:
- 二分
---

# 位运算入门

# 快速幂原理
