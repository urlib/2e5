---
title: 二分查找
date: 2018-12-01 20:04:27
categories: 普及
tags:
- 二分
---

# lower_bound & upper_bound

# 最大化最小值


# 尺取法(two-pointers)

# 最大化平均值


