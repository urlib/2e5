---
title: hello-world
date: 2018-11-21 18:03:16
categories: 入门
tags:
- c/c++入门
---

# 开启新世界的程序 

```
#include <bits/stdc++.h>
using namespace std;
int main() {
    printf("hello world\n");
    return 0;
}
```
