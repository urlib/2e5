---
title: 加入我们
date: 2018-11-27 16:03:58
categories: 加入我们
tags:
- 招聘
---

# 学军中学信息学团队简介

[最新战绩](https://mp.weixin.qq.com/s?__biz=MzA4NTI5NDE0NA==&mid=2666994521&idx=1&sn=9b3ca2da4b8c65afe2e4fce8e7d2c76f&chksm=84d99676b3ae1f60685db01456e0b89b76f99fabef438bfbfefe151091bd8f64a2f7aaead17f&mpshare=1&scene=1&srcid=1127UFUupcYl71jRXNb9dZ05&pass_ticket=LacnTfviSXFAeTp9YQ89sS0rlMwuhaAC6iTw1s2CBkNHfebEYyXgO6pR6OootF54#rd)
[以往成就](https://mp.weixin.qq.com/s?__biz=MzA4NTI5NDE0NA==&mid=2666993992&idx=1&sn=6d5b4ce308e6258cb9a8a69c2aa24bd5&chksm=84d99467b3ae1d7140cc0f6a6d3f521b29301ee69d12a78afc1c76bc5da3658c272625b476fe&mpshare=1&scene=1&srcid=1127IZyYdwcmn87i0O1QgIce&pass_ticket=LacnTfviSXFAeTp9YQ89sS0rlMwuhaAC6iTw1s2CBkNHfebEYyXgO6pR6OootF54#rd)

# 教练生活
你是否想象过边打比赛还能边工作的生活，没错，OI教练就能满足你

信息学竞赛会在未来几年达到一个巅峰状态，越来越多的学生想要参与进来

作为信息竞赛教练，我们经常要跟学生一起并肩作战，通过一场场网络赛，一轮轮现场赛的锻炼，全面提升学生的能力，培养他们不怕苦难的品格

同时我们也会自己举办一系列的比赛，比如我们承办了2018年的浙江省NOIP复赛，未来还会有更多惊喜

当然，作为教练，带学生出去比赛是家常便饭，跟我们以前做选手是类似的，只不过角色变了

工作的时间上是周期性的，一般每年的比赛季（暑假一直到11月份）是最忙的，比赛结束后都会开始总结与筹备下一年的发展

总之，这一行需要对算法竞赛本身非常热爱的人加入，你们参加竞赛之初的那份热爱会体现在孩子们每天的成长之上

我们的目标是培养一大批计算机拔尖人才，大部分人能走上国内一流的名校

如今，一小撮尖子生的时代已经过去了，如何让一大批人都能学得更好是我们一直在在做的


工作目标就是一个：学生打出好成绩



# 招聘要求

- 女士优先(本校女选手越来越多，教练团队也要同步跟上)
- ICPC/CCPC铜牌或以上(每个级别我们会对您有不同的工作安排)
- 2019年毕业或者已经工作过的都可以（如果是2020年毕业离杭州近的，也可以考虑先来实习体验）
- 熟悉linux，独立开发过一些项目,尤其是熟悉OJ开发的会加分（因为我们需要不停的开发内部平台）
- 最重要的一点是热爱算法竞赛，愿意全力帮助青少年，使他们少走弯路

# 待遇

- 根据不同竞赛经历的人不太一样，所以如果感兴趣，可以面谈, 数量上不低于一线互联网公司


# 联系方式

发送简历到下方的邮箱，如果感觉合适，我们会与您联系

email: problem_solving@foxmail.com


