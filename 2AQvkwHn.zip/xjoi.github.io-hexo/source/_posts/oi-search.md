---
title: 如何查询一名oi选手的综合实力
date: 2018-12-17 18:29:10
categories: 竞赛周边
tags:
---

# 如何查询一名oi选手的综合实力

首先是NOI官网上的历史成绩搜索

http://www.noi.cn/awardsearch.html

其次，如果你知道这名选手在竞赛圈内的常用ID(比如叫做username)，可以访问

codeforces.com/profile/username

CF上常见的实力档位从上往下依次是是红名，橙名，紫名，蓝名，绿名，灰名

看这名选手的rating曲线的分布，可以大致判断选手的实力

