

## Why
众所周知，算法竞赛发展的越来越快

在网上资源越来越多的情况下，如果没有高效的学习方法，很容易陷入所谓知识的海洋无法自拔

知识不一定就是力量，有时候是障碍

在海量的知识面前,我们需要有自己的应对之道


如果你也想搭建一个类似的博客,请看[教程](https://xjoi.github.io/hexo-github/)

到目前为止已经写了<code class="article_number"></code>篇文章， 共<code class="site_word_count"></code>字。

本站访问人数：<code class="site_uv"></code>人次 ， 访问量：<code class="site_pv"></code>次

## 博客平台
这个博客通过 [Hexo](https://hexo.io/) 生成，部署在 [GitHub Pages](https://pages.github.com/)，主题 [3-hexo](https://github.com/yelog/hexo-theme-3-hexo) 已经在github上开源

主要功能：
- 搜索支持文章标题、标签(#标签)、作者(@作者)
- pad/手机等移动端适配


>尽管去做你真正热爱的事情！别做其他事情！你的时间太少了。你怎么会想到要浪费时间做某些你不喜欢的事情来谋生呢？那算什么谋生啊？那不叫谋生，那是谋死--------与神对话

